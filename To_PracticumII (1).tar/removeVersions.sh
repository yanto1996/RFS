#!/bin/bash

./rfs RM versions/testReceived.txt